local cfg1 = require("config.config-1")



for _, v in pairs(cfg1.enty_types) do
  require("prototypes."..v)
end
