local MSlib = {}

local showlog = false     -- Debug log message toggle
local showprint = false   -- Debug game print toggle

function MSlib.debuglog(msg)
  if showlog then log(msg) end
  return showlog
end

function MSlib.debuglog_box(box)
  local logstr = ""
  for k1, v1 in pairs(box) do
    logstr = logstr .. "{ "
    for k2, v2 in pairs(v1) do
      logstr = logstr .. v2 .. " "
    end
    logstr = logstr .. "} "
  end
  if showlog then log(logstr) end
  return showlog
end

function MSlib.debugprint(msg)
  if showprint and game then game.print(msg) end
  return showprint
end



function MSlib.sign(val)
  return (val > 0 and 1) or (val == 0 and 0) or -1
end

function MSlib.value_multiply(val, scale)
  if not val then return nil end
  return val * scale
end

function MSlib.string_multiply_values(str, scale)
  if not str then return nil end
  -- local rs
  -- log("  Input string: '"..str.."'")
  -- rs = string.gsub(str, "([+-]?[%d%.]+)", function(x) log("    "..x) return tonumber(x)*scale end)
  -- log("  Output string: '"..rs.."'")
  -- return rs
  return string.gsub(str, "([+-]?[%d%.]+)", function(x) return tonumber(x)*scale end)
end

function MSlib.table_contain(t, val)
  for _, tval in pairs(t) do
    if tval == val then return true end
  end
  return false
end

function MSlib.vector_multiply(vector, scale)
  if not (vector and scale) then
    return vector
  end
  return {vector[1] * scale, vector[2] * scale}
end

function MSlib.table_multiply(t, scale)
  if not (t and scale) then
    return t
  end
  for k, v in pairs(t) do
    t[k] = v * scale
  end
  return t
end

function MSlib.table_recursive_multiply(t, scale)
  if not (t and scale) then
    return t
  end
  for k, v in pairs(t) do
    if type(v) == "table" then
      MSlib.table_recursive_multiply(v, scale)
    elseif type(v) == "number" then
      t[k] = v * scale
    end
  end
  return t
end

function MSlib.box_copy(box, scale)
  if not box then
    return box
  end
  local bbox = table.deepcopy(box)
  if scale then
    for k1, v1 in pairs(bbox) do
      for k2, v2 in pairs(v1) do
        bbox[k1][k2] = v2 * scale
      end
    end
  end
  return bbox
end

function MSlib.box_rescale(box, baselen, scale, proportional)
  -- In = {{-1.2, -1.2}, {1.2, 1.2}}, baselen = 1.5 or {1.5, 1.5}
  -- Out = {{0.3-1.5*scale, 0.3-1.5*scale}, {-0.3+1.5*scale, -0.3+1.5*scale}}
  if not box then return nil end
  MSlib.debuglog("== RESCALE "..scale.. " with base length "..tostring(baselen))
  MSlib.debuglog_box(box)
  local bbox
  if type(baselen) == "number" then
    bbox = {{-baselen, -baselen}, {baselen, baselen}}
  elseif type(baselen[1]) == "number" then
    bbox = {MSlib.vector_multiply(baselen, -1), baselen}
  else
    bbox = baselen
  end
  for k1, v1 in pairs(box) do
    for k2, v2 in pairs(v1) do
      if scale > 1 then
        if proportional then
          box[k1][k2] = scale * (v2 - bbox[1][k2]) + scale * bbox[1][k2]
        else
          local i1 = (v2 > 0 and 2) or 1
          -- box[k1][k2] = v2 + (scale-1) * bbox[k2]*bsign[k1]
          -- box[k1][k2] = v2 + (scale-1) * bbox[k2]*MSlib.sign(v2)
          box[k1][k2] = v2 + (scale-1) * bbox[i1][k2]
        end
      else
        box[k1][k2] = v2 * scale
      end
    end
  end
  MSlib.debuglog_box(box)
  return box
end

function MSlib.sprite_rescale_recursive(layer, linescale, animscale, spritesspec)
  if not layer or type(layer) ~= "table" then return nil end
  local spec = spritesspec or {}
  if layer.width then
    local isanim = layer.animation_speed or layer.frame_count
    layer.shift = MSlib.vector_multiply(layer.shift, linescale)
    if not spec.skipscale then
      layer.scale = (layer.scale or 1) * linescale * (spec.scalemul or 1)
    end
    if isanim and not spec.skipanimscale and not spec.constant_speed then
      layer.animation_speed = (layer.animation_speed or 1) * animscale
    end
    if layer.hr_version then
      layer.hr_version.shift = MSlib.vector_multiply(layer.hr_version.shift, linescale)
      if not spec.skipscale then
        layer.hr_version.scale = (layer.hr_version.scale or 1) * linescale * (spec.scalemul or 1)
      end
      if isanim and not spec.skipanimscale and not spec.constant_speed then
        layer.hr_version.animation_speed = (layer.hr_version.animation_speed or 1) * animscale
      end
    end
  else
    if layer.constant_speed then
      spec = table.deepcopy(spec)
      spec.skipanimscale = true
    end
    for k, v in pairs(layer) do
      if type(k) == "string" and k:match("_position$") then
        layer[k] = MSlib.vector_multiply(v, linescale)
      else
        MSlib.sprite_rescale_recursive(v, linescale, animscale, spec)
      end
    end
  end
  if layer.points then
    MSlib.table_recursive_multiply(layer.points, linescale)
  end
  return layer
end

function MSlib.connections_rescale(connections, baselen, linescale, tier, fbspec)
  if not connections then return nil end
  if type(connections) ~= "table" then return nil end
  if not baselen then return nil end
  local spec = fbspec or {}
  local bbox
  if type(baselen) == "number" then
    bbox = {{-baselen, -baselen}, {baselen, baselen}}
  elseif type(baselen[1]) == "number" then
    bbox = {MSlib.vector_multiply(baselen, -1), baselen}
  else
    bbox = baselen
  end
  local rt = {}
  if spec.spreadpipe then
    -- Spread pipe
    MSlib.debuglog("  == Spread ==")
    for k, v in pairs(connections) do
      MSlib.debuglog("  " .. v.position[1] .. ", " .. v.position[2] .. " in tier " .. tier .. " :")
      local rv = table.deepcopy(v)
      if v.direction == defines.direction.south then
      -- if ( v.position[2] > bbox[2][2] ) or ( v.position[2] > math.abs(v.position[1]) ) then
        -- Connection at +y (bottom) or -y (top)
        -- Spread over x
        -- local y_N = v.position[2] + (linescale-1) * bbox[2] * MSlib.sign(v.position[2])
        MSlib.debuglog("    Case y+")
        local y_N = v.position[2] + (linescale-1) * bbox[2][2]
        for i = 0, tier, 1 do
          local x_N = v.position[1] + (v.position[1] - 0.5) * tier + i
          MSlib.debuglog("      ( " .. x_N .. ", " .. y_N .. " )")
          rv.position = {x_N, y_N}
          table.insert( rt, table.deepcopy(rv) )
        end
      elseif v.direction == defines.direction.north then
      -- elseif ( v.position[2] < bbox[1][2] ) or ( v.position[2] < -math.abs(v.position[1]) ) then
        -- Connection at +y (bottom) or -y (top)
        -- Spread over x
        MSlib.debuglog("Case y-")
        local y_N = v.position[2] + (linescale-1) * bbox[1][2]
        for i = 0, tier, 1 do
          local x_N = v.position[1] + (v.position[1] - 0.5) * tier + i
          MSlib.debuglog("      ( " .. x_N .. ", " .. y_N .. " )")
          rv.position = {x_N, y_N}
          table.insert( rt, table.deepcopy(rv) )
        end      
      elseif v.direction == defines.direction.east then
      -- elseif ( v.position[1] > bbox[2][1] ) or ( v.position[1] > math.abs(v.position[2]) ) then
        -- Connection at +x (right) or -x (left)
        -- Spread over y
        -- local x_N = v.position[1] + (linescale-1) * bbox[1] * MSlib.sign(v.position[1])
        MSlib.debuglog("Case x+")
        local x_N = v.position[1] + (linescale-1) * bbox[2][1]
        for i = 0, tier, 1 do
          local y_N = v.position[2] + (v.position[2] - 0.5) * tier + i
          MSlib.debuglog("      ( " .. x_N .. ", " .. y_N .. " )")
          rv.position = {x_N, y_N}
          table.insert( rt, table.deepcopy(rv) )
        end      
      elseif v.direction == defines.direction.west then
      -- elseif ( v.position[1] < bbox[1][1] ) or ( v.position[1] < -math.abs(v.position[2]) ) then
        -- Connection at +x (right) or -x (left)
        -- Spread over y
        MSlib.debuglog("Case x-")
        local x_N = v.position[1] + (linescale-1) * bbox[1][1]
        for i = 0, tier, 1 do
          local y_N = v.position[2] + (v.position[2] - 0.5) * tier + i
          MSlib.debuglog("      ( " .. x_N .. ", " .. y_N .. " )")
          rv.position = {x_N, y_N}
          table.insert( rt, table.deepcopy(rv) )
        end      
      else
        -- Indetermined, as it is not defined how to spread connections
        MSlib.debuglog("    Case 0")
      end
    end
  elseif spec.singlepipe then
    -- Spread pipe
    MSlib.debuglog("  == Single ==")
    for k, v in pairs(connections) do
      MSlib.debuglog("  " .. v.position[1] .. ", " .. v.position[2] .. " in tier " .. tier .. " :")
      local rv = table.deepcopy(v)
      if v.direction == defines.direction.south then
      -- if ( v.position[2] > bbox[2][2] ) or ( v.position[2] > math.abs(v.position[1]) ) then
        -- Connection at +y (bottom) or -y (top)
        -- Spread over x
        -- local y_N = v.position[2] + (linescale-1) * bbox[2] * MSlib.sign(v.position[2])
        MSlib.debuglog("    Case y+")
        local y_N = v.position[2] + (linescale-1) * bbox[2][2]
        i = math.floor(tier*0.5)
          local x_N = v.position[1] + (v.position[1] - 0.5) * tier + i
          MSlib.debuglog("      ( " .. x_N .. ", " .. y_N .. " )")
          rv.position = {x_N, y_N}
          table.insert( rt, table.deepcopy(rv) )
      elseif v.direction == defines.direction.north then
      -- elseif ( v.position[2] < bbox[1][2] ) or ( v.position[2] < -math.abs(v.position[1]) ) then
        -- Connection at +y (bottom) or -y (top)
        -- Spread over x
        MSlib.debuglog("    Case y-")
        local y_N = v.position[2] + (linescale-1) * bbox[1][2]
        i = math.floor(tier*0.5)
          local x_N = v.position[1] + (v.position[1] - 0.5) * tier + i
          MSlib.debuglog("      ( " .. x_N .. ", " .. y_N .. " )")
          rv.position = {x_N, y_N}
          table.insert( rt, table.deepcopy(rv) )
      elseif v.direction == defines.direction.east then
      -- elseif ( v.position[1] > bbox[2][1] ) or ( v.position[1] > math.abs(v.position[2]) ) then
        -- Connection at +x (right) or -x (left)
        -- Spread over y
        -- local x_N = v.position[1] + (linescale-1) * bbox[1] * MSlib.sign(v.position[1])
        MSlib.debuglog("    Case x+")
        local x_N = v.position[1] + (linescale-1) * bbox[2][1]
        i = math.floor(tier*0.5)
          local y_N = v.position[2] + (v.position[2] - 0.5) * tier + i
          MSlib.debuglog("      ( " .. x_N .. ", " .. y_N .. " )")
          rv.position = {x_N, y_N}
          table.insert( rt, table.deepcopy(rv) )
      elseif v.direction == defines.direction.west then
      -- elseif ( v.position[1] < bbox[1][1] ) or ( v.position[1] < -math.abs(v.position[2]) ) then
        -- Connection at +x (right) or -x (left)
        -- Spread over y
        MSlib.debuglog("    Case x-")
        local x_N = v.position[1] + (linescale-1) * bbox[1][1]
        i = math.floor(tier*0.5)
          local y_N = v.position[2] + (v.position[2] - 0.5) * tier + i
          MSlib.debuglog("      ( " .. x_N .. ", " .. y_N .. " )")
          rv.position = {x_N, y_N}
          table.insert( rt, table.deepcopy(rv) )
      else
        -- Indetermined, as it is not defined how to spread connections
        MSlib.debuglog("    Case 0")
      end
    end
  else
    -- Simple pipe
    MSlib.debuglog("  == Simple ==")
    for k, v in pairs(connections) do
      MSlib.debuglog("  " .. v.position[1] .. ", " .. v.position[2] .. " in tier " .. tier .. " :")
      local rv = table.deepcopy(v)
      MSlib.debuglog("    Case Simple")
      -- No single solution, so just using the simple expansion method
      local y_N = 0
      if v.position[2] > 0 then
        y_N = v.position[2] + (linescale-1) * bbox[2][2]
      elseif v.position[2] < 0 then
        y_N = v.position[2] + (linescale-1) * bbox[1][2]
      end
      local x_N = 0
      if v.position[1] > 0 then
        x_N = v.position[1] + (linescale-1) * bbox[2][1]
      elseif v.position[1] < 0 then
        x_N = v.position[1] + (linescale-1) * bbox[1][1]
      end
      MSlib.debuglog("      ( " .. x_N .. ", " .. y_N .. " )")
      rv.position = {x_N, y_N}
      table.insert( rt, table.deepcopy(rv) )
    end      
  end
  return rt
end

function MSlib.fluid_box_rescale(fbox, baselen, linescale, multscale, tier, fbspec)
  if not fbox then return nil end
  if type(fbox) ~= "table" then return nil end
  if not baselen then return nil end
  local spec = fbspec or {}
  fbox.volume = (fbox.volume or 1) * multscale
  fbox.pipe_connections = MSlib.connections_rescale(fbox.pipe_connections, baselen, linescale, tier, spec)
  return fbox
end

function MSlib.fluid_boxes_rescale(fboxes, baselen, linescale, multscale, tier, spec)
  if not fboxes then return nil end
  if not baselen then return nil end
  for _, v in pairs(fboxes) do
    MSlib.fluid_box_rescale(v, baselen, linescale, multscale, tier, spec)
  end
end

function MSlib.circuit_wire_distance_rescale(val, baselen, linescale, tier, entyspec)
  if not val or val < 1 then return val end
  if not baselen then return nil end
  local spec = entyspec or {}
  local ext_per_tier = 0
  if spec.wire_distance_per_tier then
    ext_per_tier = spec.wire_distance_per_tier
  elseif type(baselen) == "number" then
    ext_per_tier = baselen
  elseif type(baselen[1]) == "number" then
    ext_per_tier = math.abs(baselen[1])
  else
    ext_per_tier = 2
  end
  return math.ceil(val + ext_per_tier* tier)
end



return MSlib
