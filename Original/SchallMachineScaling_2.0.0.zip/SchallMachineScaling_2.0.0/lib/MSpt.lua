local MSlib = require("lib.MSlib")
local cfg1 = require("config.config-1")
local basept = require("lib.base-pt")



local MSpt = {}

MSpt.mod_name = "__SchallMachineScaling__"
MSpt.mod_domain = "Schall-MS"
MSpt.overtier_icon_prefix = MSpt.mod_name.."/graphics/icons/overtier-"
MSpt.overtier_icon_suffix = ".png"
MSpt.overtier_icon_tint = {r=1.0, g=1.0, b=0.0, a=1}
MSpt.tech_MS_icon_layer = {icon = MSpt.mod_name.."/graphics/technology/overtier.png", icon_size = 256, icon_mipmaps = 4}
MSpt.icon_size_def = 64

local dr = data.raw


function MSpt.get_linescale(tier)
  return tier+1
end

function MSpt.get_multscale(tier)
  return math.pow(4, tier)
end

function MSpt.PT_name(mainname, tier)
  if tier < 1 then return mainname end
  return mainname.."-MS-"..tier
end

function MSpt.PT_tech_name(mainname, tier)
  return mainname.."-MS-"..tier
end

function MSpt.PT_localised_name(mainname, tier, domainname)
  local domain = domainname and (domainname .. ".") or "entity-name."
  return { "entity-name."..MSpt.mod_domain.."-localised-name", {domain..mainname}, tostring(tier) }
end

function MSpt.PT_localised_description(mainname, tier)
  return { "entity-description."..MSpt.mod_domain.."-localised-description", {"entity-name."..mainname}, tostring(MSpt.get_multscale(tier)) }
end

function MSpt.overtier_icon_layer(tier)
  return {icon = MSpt.overtier_icon_prefix .. tier .. MSpt.overtier_icon_suffix, tint = MSpt.overtier_icon_tint, icon_size = 128, icon_mipmaps = 3}
end

function MSpt.icons_add_layer(pt, add_layer)
  if not add_layer.icon then return nil end
  add_layer.icon_size = add_layer.icon_size or MSpt.icon_size_def
  local rt
  if pt.icons then
    rt = table.deepcopy(pt.icons)
    table.insert(rt, add_layer)
    return rt
  elseif pt.icon then
    rt =
    {
      { icon = pt.icon, icon_size = pt.icon_size or MSpt.icon_size_def },
      add_layer
    }
    return rt
  end
  return nil
end

function MSpt.icons_add_overtier_layer(pt, tier)
  return MSpt.icons_add_layer(pt, MSpt.overtier_icon_layer(tier))
end

function MSpt.PT_icons(mainname, tier, iconspec)
  local iconpath
  local spec = iconspec or {}
  if spec.path then
    iconpath = spec.path.."/graphics/icons/"..(spec.iconname or mainname)..".png"
  elseif spec.usemodpath then
    iconpath = MSpt.mod_name.."/graphics/icons/"..(spec.iconname or mainname)..".png"
  else
    iconpath = "__base__/graphics/icons/"..(spec.iconname or mainname)..".png"
  end
  return {
    {icon = iconpath, icon_size = spec.icon_size or 64, icon_mipmaps = spec.icon_mipmaps or 4},
    MSpt.overtier_icon_layer(tier)
  }
end

function MSpt.PT_tech_icons(mainname, tier, iconspec)
  local iconpath
  local spec = iconspec or {}
  if spec.path then
    iconpath = spec.path.."/graphics/technology/"..(spec.iconname or mainname)..".png"
  elseif spec.usemodpath then
    iconpath = MSpt.mod_name.."/graphics/technology/"..(spec.iconname or mainname)..".png"
  else
    iconpath = "__base__/graphics/technology/"..(spec.iconname or mainname)..".png"
  end
  return {
    {icon = iconpath, icon_size = 256, icon_mipmaps = 4},
    MSpt.tech_MS_icon_layer,
  }
end

function MSpt.PT_item(mainname, spec, tier)
  if not spec then spec = {} end
  local itemname = MSpt.PT_name(mainname, tier)
  local item = table.deepcopy(dr.item[spec.basename or mainname])
  local order = item.order .. (spec.ordersuffix or "")
  item.name = itemname
  item.localised_name = MSpt.PT_localised_name(mainname, tier)
  item.localised_description = MSpt.PT_localised_description(spec.basename or mainname, tier)
  -- item.icons = MSpt.PT_icons(mainname, tier, spec.icon)
  item.icons = MSpt.icons_add_overtier_layer(item, tier)
  -- item.subgroup = item.subgroup
  item.order = order.."-"..tier
  item.place_result = itemname
  if item.weight then
    item.weight = item.weight * (2 ^ (tier))
  else
    item.weight = ( tons / item.stack_size ) * (2 ^ (tier) )
  end
  item.stack_size = (spec.item and spec.item.stack_size) or 10
  return item
end

local icons_pos_def = {
  ["assembling-machine"] = {
    {inventory_index = defines.inventory.assembling_machine_modules,  shift = {0, 0.7}, scale = 0.5},
  },
  ["lab"] = {
    {inventory_index = defines.inventory.lab_modules,                 shift = {0, 0.9}, scale = 0.5},
    {inventory_index = defines.inventory.lab_input,                   shift = {0, -0.2}, scale = 0.5, max_icons_per_row = 6, separation_multiplier = 0.9},  -- Original shift = {0, 0}, moved higher to give space for modules
  },
  ["furnace"] = {
    {inventory_index = defines.inventory.furnace_modules,             shift = {0, 0.8}, scale = 0.5},
  },
}

local function icons_pos_add_def(icons_pos, type)
  if not icons_pos then icons_pos = {} end
  if not icons_pos_def[type] then return {} end
  local found
  for kd, vd in pairs(icons_pos_def[type]) do
    found = false
    for kr, vr in pairs(icons_pos) do
      if vr.inventory_index == vd.inventory_index then
        vr.shift = vr.shift or vd.shift or {0, 0.7}
        vr.scale = vr.scale or vd.scale or 0.5
        found = true
        break
      end
    end
    if not found then
      table.insert(icons_pos, table.deepcopy(vd))
    end
  end
  return icons_pos
end

local function icons_pos_multiply(icons_pos, scale)
  if not icons_pos then return {} end
    for k, v in pairs(icons_pos) do
      v.shift = MSlib.vector_multiply(v.shift or {0, 0.7}, scale)
      v.scale = (v.scale or 0.5) * scale
    end
  return icons_pos
end

function MSpt.PT_entity(name, spec, tier, type)
  local linescale = MSpt.get_linescale(tier)
  local multscale = MSpt.get_multscale(tier)
  local animscale = 1/multscale
  local name_MS = MSpt.PT_name(name, tier)
  local enty = table.deepcopy(spec.baseenty or basept.entity[name])
  MSlib.debuglog(name_MS)
  enty.name = name_MS
  enty.localised_name = MSpt.PT_localised_name(name, tier)
  enty.localised_description = MSpt.PT_localised_description(name, tier)
  enty.icons = MSpt.icons_add_overtier_layer(enty, tier)
  enty.minable.result = name_MS
  enty.max_health = enty.max_health * linescale
  MSlib.table_multiply(enty.alert_icon_shift, linescale)
  enty.alert_icon_scale = linescale-1
  -- enty.scale_entity_info_icon = true
  -- enty.entity_info_icon_shift = {0, (spec.entity_info.icon_shift or 0)*linescale}
  MSlib.box_rescale(enty.collision_box, spec.baselen, linescale)
  MSlib.box_rescale(enty.selection_box, spec.baselen, linescale)
  MSlib.box_rescale(enty.drawing_box, spec.baselen, linescale)
  if enty.tile_buildability_rules then
    for k, v in pairs(enty.tile_buildability_rules) do
      MSlib.box_rescale(v.area, spec.baselen, linescale, true)
    end
  end
  MSlib.table_recursive_multiply(enty.window_bounding_box, linescale)
  MSlib.table_recursive_multiply(enty.horizontal_window_bounding_box, linescale)
  MSlib.table_recursive_multiply(enty.vertical_window_bounding_box, linescale)
  MSlib.fluid_boxes_rescale(enty.fluid_boxes, spec.baselen, linescale, multscale, tier, spec.fluid_box)
  MSlib.fluid_box_rescale(enty.fluid_box, spec.baselen, linescale, multscale, tier, spec.fluid_box)
  MSlib.fluid_box_rescale(enty.output_fluid_box, spec.baselen, linescale, multscale, tier, spec.fluid_box)
  MSlib.sprite_rescale_recursive(enty.graphics_set, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.pictures, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.picture, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.animations, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.on_animation, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.off_animation, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.fluid_animation, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.energy_source, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.horizontal_animation, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.vertical_animation, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.smoke, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.water_reflection, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.lower_layer_picture, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.heat_lower_layer_picture, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.glass_pictures, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.working_light_picture, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.fluid_wagon_connector_graphics, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.connection_sprites, linescale, animscale, spec.sprites)
  MSlib.sprite_rescale_recursive(enty.heat_glow_sprites, linescale, animscale, spec.sprites)
  -- MSlib.sprite_rescale_recursive(enty.connection_patches_connected, linescale, animscale, spec.sprites)
  -- MSlib.sprite_rescale_recursive(enty.connection_patches_disconnected, linescale, animscale, spec.sprites)
  -- MSlib.sprite_rescale_recursive(enty.heat_connection_patches_connected, linescale, animscale, spec.sprites)
  -- MSlib.sprite_rescale_recursive(enty.heat_connection_patches_disconnected, linescale, animscale, spec.sprites)
  enty.crafting_speed = MSlib.value_multiply(enty.crafting_speed, multscale)
  enty.researching_speed = MSlib.value_multiply(enty.researching_speed, multscale)
  enty.pumping_speed = MSlib.value_multiply(enty.pumping_speed, multscale)
  enty.tile_width = MSlib.value_multiply(enty.tile_width, linescale)
  enty.tile_height = MSlib.value_multiply(enty.tile_height, linescale)
  enty.fluid_usage_per_tick = MSlib.value_multiply(enty.fluid_usage_per_tick, multscale)
  enty.fluid_source_offset = MSlib.vector_multiply(enty.fluid_source_offset, linescale)
  enty.consumption = MSlib.string_multiply_values(enty.consumption, multscale)
  enty.energy_consumption = MSlib.string_multiply_values(enty.energy_consumption, multscale)
  enty.energy_usage = MSlib.string_multiply_values(enty.energy_usage, multscale)
  if enty.energy_source then
    enty.energy_source.emissions_per_minute = MSlib.table_multiply(enty.energy_source.emissions_per_minute, multscale)
    enty.energy_source.specific_heat = MSlib.string_multiply_values(enty.energy_source.specific_heat, multscale)
    enty.energy_source.max_transfer = MSlib.string_multiply_values(enty.energy_source.max_transfer, multscale)
    enty.energy_source.drain = MSlib.string_multiply_values(enty.energy_source.drain, multscale)
    enty.energy_source.connections = MSlib.connections_rescale(enty.energy_source.connections, spec.baselen, linescale, tier, spec.fluid_box)
    if enty.energy_source.fluid_box then
      enty.energy_source.fluid_box.pipe_connections = MSlib.connections_rescale(enty.energy_source.fluid_box.pipe_connections, spec.baselen, linescale, tier, spec.fluid_box)
    end
  end
  if enty.heat_buffer then
    enty.heat_buffer.specific_heat = MSlib.string_multiply_values(enty.heat_buffer.specific_heat, multscale)
    enty.heat_buffer.max_transfer = MSlib.string_multiply_values(enty.heat_buffer.max_transfer, multscale)
    enty.heat_buffer.connections = MSlib.connections_rescale(enty.heat_buffer.connections, spec.baselen, linescale, tier, spec.fluid_box)
  end
  enty.icon_draw_specification = enty.icon_draw_specification or {}
  enty.icon_draw_specification.shift = MSlib.vector_multiply(enty.icon_draw_specification.shift or {0,0}, linescale)
  enty.icon_draw_specification.scale = (enty.icon_draw_specification.scale or 1) * linescale
  enty.icon_draw_specification.scale_for_many = (enty.icon_draw_specification.scale_for_many or 1) * linescale
  -- enty.module_specification.module_info_icon_shift = {0, (spec.module_info.icon_shift or 0.9)*linescale}
  -- enty.module_specification.module_info_icon_scale = (spec.module_info.icon_scale or 0.5) * linescale
  enty.icons_positioning = icons_pos_add_def(enty.icons_positioning, type)
  icons_pos_multiply(enty.icons_positioning, linescale)
  MSlib.sprite_rescale_recursive(enty.circuit_connector, linescale, animscale, spec.sprites)
  enty.circuit_wire_max_distance = MSlib.circuit_wire_distance_rescale(enty.circuit_wire_max_distance, spec.baselen, linescale, tier, spec.wire_distance_per_tier)
  return enty
end

function MSpt.PT_ingredients(main_ing, modules)
  if modules and modules > 0 then
    return {
      {type = "item", name = main_ing, amount = 4},
      {type = "item", name = "speed-module-3", amount = modules},
      {type = "item", name = "productivity-module-3", amount = modules},
      {type = "item", name = "efficiency-module-3", amount = modules}
    }
  else
    return {
      {type = "item", name = main_ing, amount = 4}
    }
  end
end

function MSpt.PT_recipe_from_lower(mainname, spec, tier)
  if not spec then spec = {} end
  local itemname_MS = MSpt.PT_name(mainname, tier)
  local itemname_LS = MSpt.PT_name(mainname, tier-1)
  if tier == 1 then itemname_LS = (spec.basename or mainname) end
  local enty = (spec.baseenty or basept.entity[mainname])
  local modules = enty.module_slots or 0
  return {
    type = "recipe",
    name = itemname_MS,
    enabled = false,
    energy_required = (spec.recipe.basetime or 10) * tier,
    ingredients = MSpt.PT_ingredients(itemname_LS, modules),
    results = { {type = "item", name = itemname_MS, amount = 1} }
  }
end

function MSpt.PT_recipe_from_same(mainname, spec, tier)
  if not spec then spec = {} end
  local itemname_MS = MSpt.PT_name(mainname, tier)
  local itemname_LS = MSpt.PT_name(spec.basename or mainname, tier)
  return {
    type = "recipe",
    name = itemname_MS,
    enabled = false,
    energy_required = (spec.recipe.basetime or 10) * tier,
    ingredients =
    {
      {type = "item", name = itemname_LS, amount = 1}
    },
    results = { {type = "item", name = itemname_MS, amount = 1} }
  }
end

function MSpt.PT_technology(mainname, spec, tier)
  local techspec = spec.technology
  local itemname_MS = MSpt.PT_name(mainname, tier)
  local itemname_LS = MSpt.PT_name(mainname, tier-1)
  local prerequisites
  if tier == 1 then
    prerequisites = { techspec.prereq1 }
  else
    prerequisites = { itemname_LS }
  end
  local ingredients = techspec.ingredients or
    {
      {"automation-science-pack", 1},
      {"logistic-science-pack", 1},
      {"chemical-science-pack", 1},
      {"production-science-pack", 1}
    }
  return {
    type = "technology",
    name = itemname_MS,
    localised_name = MSpt.PT_localised_name(mainname, tier),
    localised_description = techspec.localised_description or MSpt.PT_localised_description(spec.basename or mainname, tier),
    icons = MSpt.PT_tech_icons(mainname, tier, techspec.icon),
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = itemname_MS
      }
    },
    prerequisites = prerequisites,
    unit =
    {
      count = techspec.scibase * math.pow(2, tier),
      ingredients = ingredients,
      time = techspec.time or 30
    },
    upgrade = true,
    order = techspec.order
  }
end

function MSpt.PT_technology_empty(mainname, spec, tier)
  local prerequisites
  if tier == 1 then
    prerequisites = { spec.prereq1 }
  else
    prerequisites = { MSpt.PT_tech_name(mainname, tier-1) }
  end
  local ingredients = spec.ingredients or
    {
      {"automation-science-pack", 1},
      {"logistic-science-pack", 1},
      {"chemical-science-pack", 1},
      {"production-science-pack", 1}
    }
  return {
    type = "technology",
    name = MSpt.PT_tech_name(mainname, tier),
    localised_name = MSpt.PT_localised_name(mainname, tier, spec.domainname),
    icons = MSpt.PT_tech_icons(mainname, tier, spec.icon),
    effects = {},
    prerequisites = prerequisites,
    unit =
    {
      count = spec.scibase * math.pow(2, tier),
      ingredients = ingredients,
      time = spec.time or 30
    },
    upgrade = true,
    order = spec.order
  }
end

function MSpt.append_technology(techname, unlockname, unlocktier)
  local techpt = dr.technology[techname]
  if techpt then
    table.insert( techpt.effects, { type = "unlock-recipe", recipe = MSpt.PT_name(unlockname, unlocktier) } )
  end
end



return MSpt
