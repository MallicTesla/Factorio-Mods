local MSlib = require("lib.MSlib")
local cfg1 = require("config.config-1")


local dr = data.raw

local dre
local base_name
local tier

-- Loop through all the entity types
for _, ve in pairs(cfg1.enty_types) do
  MSlib.debuglog(ve.." :")
  dre = dr[ve]
  for _, MS in pairs(dre) do
    base_name, tier = MS.name:match(cfg1.machine_name_MS_ptrn)
    if base_name and cfg1.tier_max[base_name] and tonumber(tier) > 0 then
      local text = "  " .. MS.name .. "  " .. base_name
      if tier then text = text .. " +" .. tier end
      MSlib.debuglog(text)
      -- Update settings in overtier machines, by copying from base machine, which are modified by DLC Space Age or whatever.
      MS.crafting_categories = table.deepcopy(dre[base_name].crafting_categories)
      MS.inputs = table.deepcopy(dre[base_name].inputs)
      if mods["space-age"] then
        MS.surface_conditions = table.deepcopy(dre[base_name].surface_conditions)
        -- MS.icons_positioning = table.deepcopy(dre[base_name].icons_positioning)
        for _, layer in pairs(MS.icons_positioning) do
          if layer.inventory_index == defines.inventory.lab_input then
            layer.max_icons_per_row = 6
            layer.separation_multiplier = 1/1.1
          end
        end
      end
    end
  end
end

-- Support mod "Disco Science"
dre = dr.lab
base_name = "lab"
for _, v in pairs(dre) do
  for tier = 1, cfg1.tier_max[base_name] or 0, 1 do
    if mods["DiscoScience"] and DiscoScience and DiscoScience.prepareLab then
      DiscoScience.prepareLab(dre[base_name.."-MS-"..tier])
    end
  end
end
