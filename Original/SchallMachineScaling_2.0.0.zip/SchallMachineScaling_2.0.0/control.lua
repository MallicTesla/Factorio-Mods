local function updateDiscoScience()
  local tier_max = settings.startup["Schall-MS-tier-lab"].value
  local machine_name = "lab"
  if remote.interfaces["DiscoScience"] and remote.interfaces["DiscoScience"]["setLabScale"] then
    for tier = 1, tier_max, 1 do
      machine_name_MS = machine_name.."-MS-"..tier
      remote.call("DiscoScience", "setLabScale", machine_name.."-MS-"..tier, tier)
    end
  end
end


local function on_init()
  updateDiscoScience()
end

local function on_configuration_changed()
  updateDiscoScience()
end



script.on_init(                                                     on_init)
script.on_configuration_changed(                                    on_configuration_changed)
