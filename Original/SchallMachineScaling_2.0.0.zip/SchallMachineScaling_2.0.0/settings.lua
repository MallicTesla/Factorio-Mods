data:extend{
  -- Machine Scaling
  {
    type = "int-setting",
    name = "Schall-MS-tier-assembling-machine-3",
    order = "ms-ot-a",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-chemical-plant",
    order = "ms-ot-b",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-electric-furnace",
    order = "ms-ot-c",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-oil-refinery",
    order = "ms-ot-d",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-centrifuge",
    order = "ms-ot-e",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-lab",
    order = "ms-ot-f",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-boiler",
    order = "ms-ot-o",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6, 7 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-steam-engine",
    order = "ms-ot-p",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6, 7 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-steam-turbine",
    order = "ms-ot-q",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6, 7 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-heat-exchanger",
    order = "ms-ot-r",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6, 7 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-nuclear-reactor",
    order = "ms-ot-s",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6 }
  },
  {
    type = "int-setting",
    name = "Schall-MS-tier-storage-tank",
    order = "ms-ot-t",
    setting_type = "startup",
    default_value = 2,
    allowed_values = { 0, 1, 2, 3, 4, 5, 6, 7 }
  },
}
