local cfg1 = require("config.config-1")
local MSpt = require("lib.MSpt")



local PT_type = "assembling-machine"
local PT_specs =
{
  ["assembling-machine-3"] = {
    -- tier_max = 1, -- Only needed if not reading from options
    -- basename = "assembling-machine-3", -- Only needed if "derived" from another item/entity
    -- ordersuffix = "",  -- Only needed if put in subgroups
    baselen = {1.5, 1.5},
    -- baseenty = data.raw["x"]["y"], -- Only needed if not reading from basept
    icon = {
      -- path = "", -- Only needed if using custom path
      -- usemodpath = false,  -- Default using base path
      -- iconname = "",
    },
    sprites = {
      scalemul = 1.1,
      -- skipscale = false,
      -- skipanimscale = false,
    },
    recipe = {
      basetime = 10,
    },
    technology = {
      prereq1 = "automation-3",
      scibase = 150,
      order = "ms-a-a",
      icon = {
        -- path = "", -- Only needed if using custom path
        usemodpath = true,  -- Default using base path
        -- iconname = "",
      },
      -- append = {  -- If not creating independent tech
      --   tech = "heat-exchanger-MS-",
      -- },
    },
    fluid_box = {
      spreadpipe = true,
    },
    entity_info = {
      -- icon_shift = 0,
    },
    module_info = {
      -- icon_shift = 0.9,
      -- icon_scale = 0.5,
    },
  },
  ["chemical-plant"] = {
    -- tier_max = 1, -- Only needed if not reading from options
    -- basename = "assembling-machine-3", -- Only needed if "derived" from another item/entity
    -- ordersuffix = "",  -- Only needed if put in subgroups
    baselen = {1.5, 1.5},
    -- baseenty = data.raw["x"]["y"], -- Only needed if not reading from basept
    icon = {
      -- path = "", -- Only needed if using custom path
      -- usemodpath = false,  -- Default using base path
      -- iconname = "",
    },
    sprites = {
      -- scalemul = 1,
      -- skipscale = false,
      -- skipanimscale = false,
    },
    recipe = {
      basetime = 10,
    },
    technology = {
      prereq1 = "oil-processing",
      scibase = 150,
      order = "ms-a-d",
      icon = {
        -- path = "", -- Only needed if using custom path
        usemodpath = true,  -- Default using base path
        -- iconname = "",
      },
      -- append = {  -- If not creating independent tech
      --   tech = "heat-exchanger-MS-",
      -- },
    },
    fluid_box = {
      spreadpipe = true,
    },
    entity_info = {
      -- icon_shift = 0,
    },
    module_info = {
      -- icon_shift = 0.9,
      -- icon_scale = 0.5,
    },
  },
  ["centrifuge"] = {
    -- tier_max = 1, -- Only needed if not reading from options
    -- basename = "assembling-machine-3", -- Only needed if "derived" from another item/entity
    -- ordersuffix = "",  -- Only needed if put in subgroups
    baselen = {1.5, 1.5},
    -- baseenty = data.raw["x"]["y"], -- Only needed if not reading from basept
    icon = {
      -- path = "", -- Only needed if using custom path
      -- usemodpath = false,  -- Default using base path
      -- iconname = "",
    },
    sprites = {
      -- scalemul = 1,
      -- skipscale = false,
      -- skipanimscale = false,
    },
    recipe = {
      basetime = 10,
    },
    technology = {
      prereq1 = "uranium-processing",
      scibase = 150,
      order = "ms-a-g",
      icon = {
        -- path = "", -- Only needed if using custom path
        usemodpath = true,  -- Default using base path
        -- iconname = "",
      },
      -- append = {  -- If not creating independent tech
      --   tech = "heat-exchanger-MS-",
      -- },
    },
    fluid_box = {
      spreadpipe = true,
    },
    entity_info = {
      -- icon_shift = 0,
    },
    module_info = {
      -- icon_shift = 0.9,
      -- icon_scale = 0.5,
    },
  },
  ["oil-refinery"] = {
    -- tier_max = 1, -- Only needed if not reading from options
    -- basename = "assembling-machine-3", -- Only needed if "derived" from another item/entity
    -- ordersuffix = "",  -- Only needed if put in subgroups
    baselen = {2.5, 2.5},
    -- baseenty = data.raw["x"]["y"], -- Only needed if not reading from basept
    icon = {
      -- path = "", -- Only needed if using custom path
      -- usemodpath = false,  -- Default using base path
      -- iconname = "",
    },
    sprites = {
      -- scalemul = 1,
      -- skipscale = false,
      -- skipanimscale = false,
    },
    recipe = {
      basetime = 10,
    },
    technology = {
      prereq1 = "oil-processing",
      scibase = 150,
      order = "ms-a-c",
      icon = {
        -- path = "", -- Only needed if using custom path
        usemodpath = true,  -- Default using base path
        -- iconname = "",
      },
      -- append = {  -- If not creating independent tech
      --   tech = "heat-exchanger-MS-",
      -- },
    },
    fluid_box = {
      spreadpipe = true,
    },
    entity_info = {
      -- icon_shift = 0,
    },
    module_info = {
      icon_shift = 1.5,
      -- icon_scale = 0.5,
    },
  },
  -- ["electromagnetic-plant"] = {
  --   tier_max = 4, -- Only needed if not reading from options
  --   -- basename = "assembling-machine-3", -- Only needed if "derived" from another item/entity
  --   -- ordersuffix = "",  -- Only needed if put in subgroups
  --   baselen = {2, 2},
  --   baseenty = data.raw[PT_type]["electromagnetic-plant"], -- Only needed if not reading from basept
  --   icon = {
  --     -- path = "", -- Only needed if using custom path
  --     -- usemodpath = false,  -- Default using base path
  --     -- iconname = "",
  --   },
  --   sprites = {
  --     -- scalemul = 1,
  --     -- skipscale = false,
  --     -- skipanimscale = false,
  --   },
  --   recipe = {
  --     basetime = 10,
  --   },
  --   technology = {
  --     prereq1 = "electromagnetic-plant",
  --     scibase = 150,
  --     order = "ms-a-c",
  --     icon = {
  --       path = "__space-age__", -- Only needed if using custom path
  --       -- usemodpath = true,  -- Default using base path
  --       -- iconname = "",
  --     },
  --     -- append = {  -- If not creating independent tech
  --     --   tech = "heat-exchanger-MS-",
  --     -- },
  --   },
  --   fluid_box = {
  --     spreadpipe = true,
  --   },
  --   entity_info = {
  --     -- icon_shift = 0,
  --   },
  --   module_info = {
  --     icon_shift = 1.5,
  --     -- icon_scale = 0.5,
  --   },
  -- },
}



local dataextendlist = {}

local dre = data.raw[PT_type]
local tier_max

for name, spec in pairs(PT_specs) do
  tier_max = (dre[name] and (spec.tier_max or cfg1.tier_max[name]) or 0)
  for tier = 1, tier_max, 1 do
    table.insert( dataextendlist, MSpt.PT_item(name, spec, tier) )
    table.insert( dataextendlist, MSpt.PT_entity(name, spec, tier, PT_type) )
    table.insert( dataextendlist, MSpt.PT_recipe_from_lower(name, spec, tier) )
    if spec.technology.append then
      MSpt.append_technology(spec.technology.append.tech .. tier, name, tier)
    else
      table.insert( dataextendlist, MSpt.PT_technology(name, spec, tier) )
    end
  end
end

if next(dataextendlist) ~= nil then
  data:extend(dataextendlist)
end
