local cfg1 = require("config.config-1")
local MSpt = require("lib.MSpt")



local PT_type = "reactor"
local PT_specs =
{
  ["nuclear-reactor"] = {
    -- tier_max = 1, -- Only needed if not reading from options
    -- basename = "assembling-machine-3", -- Only needed if "derived" from another item/entity
    -- ordersuffix = "",  -- Only needed if put in subgroups
    baselen = {2.5, 2.5},
    -- baseenty = data.raw["x"]["y"], -- Only needed if not reading from basept
    icon = {
      -- path = "", -- Only needed if using custom path
      -- usemodpath = false,  -- Default using base path
      -- iconname = "",
    },
    sprites = {
      -- scalemul = 1,
      -- skipscale = false,
      -- skipanimscale = false,
    },
    recipe = {
      basetime = 10,
    },
    technology = {
      prereq1 = "nuclear-power",
      scibase = 300,
      order = "ms-o-c",
      icon = {
        -- path = "", -- Only needed if using custom path
        usemodpath = true,  -- Default using base path
        -- iconname = "",
      },
      -- append = {  -- If not creating independent tech
      --   tech = "heat-exchanger-MS-",
      -- },
    },
    fluid_box = {
      spreadpipe = true,
    },
    entity_info = {
      -- icon_shift = 0,
    },
    module_info = {
      -- icon_shift = 0.9,
      -- icon_scale = 0.5,
    },
  },
}



local function PT_connections(tier)
  -- Special connections for nuclear-reactor, as number of connections are limited
  local linescale = MSpt.get_linescale(tier)
  local multscale = MSpt.get_multscale(tier)
  local rt = {}
  local y = 2.5*tier + 2
  local x_N = {}
      -- ori: -2, 0, 2
      -- +1:  -4.5, -0.5, 4.5
      -- +2:  -7, 0, 7
  -- log("Tier +" .. tier .. "  y = " .. y)
  for i = 0, 2, 1 do
    x_N[i] = -2.5*tier - 2 + math.floor( (2+2.5*tier)*i )
    -- log("  ".. tostring(-2.5*tier - 2) .." , " .. tostring(math.floor( 2.5*(tier+1)*i - 0.5 )))
    -- log(x_N[i])
  end
  for _, x in pairs(x_N) do
    table.insert( rt,  { position = { x , -y }, direction = defines.direction.north } )
  end
  for _, x in pairs(x_N) do
    table.insert( rt,  { position = { y ,  x }, direction = defines.direction.east } )
  end
  for _, x in pairs(x_N) do
    table.insert( rt,  { position = { x ,  y }, direction = defines.direction.south } )
  end
  for _, x in pairs(x_N) do
    table.insert( rt,  { position = {-y ,  x }, direction = defines.direction.west } )
  end
  return rt
end

local function PT_entity(name, spec, tier, type)
  local enty = MSpt.PT_entity(name, spec, tier, PT_type)
  -- enty.heat_buffer.connections = MSlib.connections_rescale(enty.heat_buffer.connections, spec.baselen, linescale, tier, spec.fluid_box)
  enty.heat_buffer.connections = PT_connections(tier) -- Special connections
  -- MSlib.sprite_rescale_recursive(enty.connection_patches_connected, linescale, animscale, spec.sprites)
  -- MSlib.sprite_rescale_recursive(enty.connection_patches_disconnected, linescale, animscale, spec.sprites)
  -- MSlib.sprite_rescale_recursive(enty.heat_connection_patches_connected, linescale, animscale, spec.sprites)
  -- MSlib.sprite_rescale_recursive(enty.heat_connection_patches_disconnected, linescale, animscale, spec.sprites)
  enty.connection_patches_connected = nil
  enty.connection_patches_disconnected = nil
  enty.heat_connection_patches_connected = nil
  enty.heat_connection_patches_disconnected = nil
  return enty
end



local dataextendlist = {}

local dre = data.raw[PT_type]
local tier_max

for name, spec in pairs(PT_specs) do
  tier_max = (dre[name] and (spec.tier_max or cfg1.tier_max[name]) or 0)
  for tier = 1, tier_max, 1 do
    table.insert( dataextendlist, MSpt.PT_item(name, spec, tier) )
    table.insert( dataextendlist, PT_entity(name, spec, tier, PT_type) )  -- Using local function, as special arrangement for heat connections
    -- table.insert( dataextendlist, MSpt.PT_entity(name, spec, tier, PT_type) )
    table.insert( dataextendlist, MSpt.PT_recipe_from_lower(name, spec, tier) )
    if spec.technology.append then
      MSpt.append_technology(spec.technology.append.tech .. tier, name, tier)
    else
      table.insert( dataextendlist, MSpt.PT_technology(name, spec, tier) )
    end
  end
end

if next(dataextendlist) ~= nil then
  data:extend(dataextendlist)
end
