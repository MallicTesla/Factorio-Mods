local cfg1 = require("config.config-1")
local MSpt = require("lib.MSpt")



local PT_type = "storage-tank"
local PT_specs =
{
  ["storage-tank"] = {
    -- tier_max = 1, -- Only needed if not reading from options
    -- basename = "assembling-machine-3", -- Only needed if "derived" from another item/entity
    -- ordersuffix = "",  -- Only needed if put in subgroups
    baselen = {1.5, 1.5},
    -- baseenty = data.raw["x"]["y"], -- Only needed if not reading from basept
    icon = {
      -- path = "", -- Only needed if using custom path
      -- usemodpath = false,  -- Default using base path
      -- iconname = "",
    },
    sprites = {
      -- scalemul = 1,
      -- skipscale = false,
      -- skipanimscale = false,
    },
    recipe = {
      basetime = 10,
    },
    technology = {
      prereq1 = "fluid-handling",
      scibase = 50,
      order = "ms-t-a",
      icon = {
        -- path = "", -- Only needed if using custom path
        usemodpath = true,  -- Default using base path
        -- iconname = "",
      },
      -- append = {  -- If not creating independent tech
      --   tech = "heat-exchanger-MS-",
      -- },
    },
    fluid_box = {
      spreadpipe = true,
    },
    entity_info = {
      -- icon_shift = 0,
      wire_distance_per_tier = 2,
    },
    module_info = {
      -- icon_shift = 0.9,
      -- icon_scale = 0.5,
    },
  },
}



local dataextendlist = {}

local dre = data.raw[PT_type]
local tier_max

for name, spec in pairs(PT_specs) do
  tier_max = (dre[name] and (spec.tier_max or cfg1.tier_max[name]) or 0)
  for tier = 1, tier_max, 1 do
    table.insert( dataextendlist, MSpt.PT_item(name, spec, tier) )
    table.insert( dataextendlist, MSpt.PT_entity(name, spec, tier, PT_type) )
    table.insert( dataextendlist, MSpt.PT_recipe_from_lower(name, spec, tier) )
    if spec.technology.append then
      MSpt.append_technology(spec.technology.append.tech .. tier, name, tier)
    else
      table.insert( dataextendlist, MSpt.PT_technology(name, spec, tier) )
    end
  end
end

if next(dataextendlist) ~= nil then
  data:extend(dataextendlist)
end
