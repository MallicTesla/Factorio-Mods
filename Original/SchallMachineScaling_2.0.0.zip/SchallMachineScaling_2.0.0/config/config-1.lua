local config = {}

config.mod_prefix         = "Schall-MS-"
config.mod_prefix_ptrn    = "Schall%-MS%-"

config.tier_max = {}
for k, v in pairs(settings.startup) do
  local obj = k:match(config.mod_prefix_ptrn .. "tier%-(.*)")
  if obj then config.tier_max[obj] = v.value end
end

config.machine_name_MS_ptrn = "(.*)%-MS%-(%d*)"
config.enty_types = {
  "assembling-machine",
  "furnace",
  "lab",
  "generator",
  "boiler",
  "storage-tank",
  "reactor",
}



return config