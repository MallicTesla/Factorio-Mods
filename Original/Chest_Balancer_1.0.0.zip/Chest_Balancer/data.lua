local util = require("util")

local lamp_proto = data.raw["lamp"]["small-lamp"]

local item = {
    type = "item",
    name = "chest-balancer",
    icon = "__base__/graphics/icons/small-lamp.png",
    icon_size = 64,
    subgroup = "storage",
    order = "a[items]-d[chest-balancer]",
    place_result = "chest-balancer",
    stack_size = 50,
}

local recipe = {
    type = "recipe",
    name = "chest-balancer",
    enabled = true,
    ingredients = {
        {type = "item", name = "iron-plate", amount = 5},
        {type = "item", name = "electronic-circuit", amount = 2},
    },
    results = {{type = "item", name = "chest-balancer", amount = 1}},
}

local entity = {
    type = "simple-entity-with-owner",
    name = "chest-balancer",
    icon = "__base__/graphics/icons/small-lamp.png",
    icon_size = 64,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 0.2, result = "chest-balancer"},
    max_health = 80,
    corpse = "small-remnants",
    dying_explosion = "lamp-explosion",
    collision_box = {{-0.35, -0.35}, {0.35, 0.35}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    picture = table.deepcopy(lamp_proto.picture_off),
    render_layer = "object",
}

data:extend({item, recipe, entity})
