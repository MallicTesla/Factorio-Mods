local UPDATE_INTERVAL = 90 --1.5 sec - should be good enough

local CHEST_TYPES = {
    ["container"] = true,
    ["logistic-container"] = true,
    ["infinity-container"] = true,
}

local function init_storage()
    storage.balancers = storage.balancers or {}
    storage.render_objects = storage.render_objects or {}
    storage.groups = storage.groups or {}
    storage.balancer_to_group = storage.balancer_to_group or {}
end

local function get_adjacent_by_type(entity, types)
    local pos = entity.position
    local surface = entity.surface
    local results = {}
    local offsets = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}}

    for _, offset in pairs(offsets) do
        local search_pos = {x = pos.x + offset[1], y = pos.y + offset[2]}
        local found = surface.find_entities_filtered{
            position = search_pos,
            type = types,
            limit = 1,
        }
        if found and #found > 0 then
            results[#results + 1] = found[1]
        end
    end

    return results
end

local function get_adjacent_by_name(entity, name)
    local pos = entity.position
    local surface = entity.surface
    local results = {}
    local offsets = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}}

    for _, offset in pairs(offsets) do
        local search_pos = {x = pos.x + offset[1], y = pos.y + offset[2]}
        local found = surface.find_entities_filtered{
            position = search_pos,
            name = name,
            limit = 1,
        }
        if found and #found > 0 then
            results[#results + 1] = found[1]
        end
    end

    return results
end

local function discover_group(start_balancer, visited_balancers)
    local group = {balancers = {}, chests = {}}
    local chest_set = {} -- duplicate chests?????
    local queue = {start_balancer}
    visited_balancers[start_balancer.unit_number] = true

    while #queue > 0 do
        local balancer = table.remove(queue, 1)
        group.balancers[#group.balancers + 1] = balancer

        local adjacent_chests = get_adjacent_by_type(balancer,
            {"container", "logistic-container", "infinity-container"})

        for _, chest in pairs(adjacent_chests) do
            local chest_id = chest.unit_number
            if not chest_set[chest_id] then
                chest_set[chest_id] = true
                group.chests[#group.chests + 1] = chest

                local adjacent_balancers = get_adjacent_by_name(chest, "chest-balancer")
                for _, next_balancer in pairs(adjacent_balancers) do
                    if not visited_balancers[next_balancer.unit_number] then
                        visited_balancers[next_balancer.unit_number] = true
                        queue[#queue + 1] = next_balancer
                    end
                end
            end
        end
    end

    return group
end

local function rebuild_all_groups()
    storage.groups = {}
    storage.balancer_to_group = {}

    local visited = {}
    local group_id = 0

    for unit_number, entity in pairs(storage.balancers) do
        if entity.valid and not visited[unit_number] then
            group_id = group_id + 1
            local group = discover_group(entity, visited)
            storage.groups[group_id] = group
            for _, balancer in ipairs(group.balancers) do
                storage.balancer_to_group[balancer.unit_number] = group_id
            end
        end
    end
end

local function collect_chest_contents(chests)
    local unique_names = {}
    local item_groups = {}

    for i, chest in ipairs(chests) do
        local inv = chest.get_inventory(defines.inventory.chest)
        if inv then
            local contents = inv.get_contents()
            for _, entry in pairs(contents) do
                unique_names[entry.name] = true
                local quality = entry.quality or "normal"
                local key = entry.name .. ":" .. quality
                if not item_groups[key] then
                    item_groups[key] = {
                        name = entry.name,
                        quality = quality,
                        counts = {},
                        total = 0,
                    }
                end
                item_groups[key].counts[i] = (item_groups[key].counts[i] or 0) + entry.count
                item_groups[key].total = item_groups[key].total + entry.count
            end
        end
    end

    return unique_names, item_groups
end

local function balance_item_group(chests, group)
    local num_chests = #chests
    local per_chest = math.floor(group.total / num_chests)
    local remainder = group.total % num_chests

    local targets = {}
    for i = 1, num_chests do
        targets[i] = per_chest + (i <= remainder and 1 or 0)
    end

    local pool = 0
    for i, chest in ipairs(chests) do
        local current = group.counts[i] or 0
        local excess = current - targets[i]
        if excess > 0 then
            local inv = chest.get_inventory(defines.inventory.chest)
            if inv then
                local removed = inv.remove({name = group.name, quality = group.quality, count = excess})
                pool = pool + removed
            end
        end
    end

    for i, chest in ipairs(chests) do
        local current = group.counts[i] or 0
        local deficit = targets[i] - current
        if deficit > 0 and pool > 0 then
            local to_insert = math.min(deficit, pool)
            local inv = chest.get_inventory(defines.inventory.chest)
            if inv then
                local inserted = inv.insert({name = group.name, quality = group.quality, count = to_insert})
                pool = pool - inserted
            end
        end
    end
end

local function update_status_light(unit_number, entity, is_working)
    local old_render = storage.render_objects[unit_number]
    if old_render and old_render.valid then
        old_render.destroy()
    end

    if not entity.valid then
        storage.render_objects[unit_number] = nil
        return
    end

    local sprite = is_working
        and "virtual-signal/signal-green"
        or "virtual-signal/signal-red"

    storage.render_objects[unit_number] = rendering.draw_sprite{
        sprite = sprite,
        target = entity,
        target_offset = {0, -0.7},
        surface = entity.surface,
        x_scale = 0.25,
        y_scale = 0.25,
    }
end

local function set_balancer_status(balancer, diode, label)
    if balancer.valid then
        balancer.custom_status = {
            diode = diode,
            label = label,
        }
    end
end

local function process_group(group_id, group)
    for _, balancer in ipairs(group.balancers) do
        if not balancer.valid then
            return false 
        end
    end
    for _, chest in ipairs(group.chests) do
        if not chest.valid then
            return false
        end
    end

    local chests = group.chests

    if #chests < 2 then
        for _, balancer in ipairs(group.balancers) do
            update_status_light(balancer.unit_number, balancer, true)
            set_balancer_status(balancer, defines.entity_status_diode.green,
                "Group " .. group_id .. " | Empty")
        end
        return true
    end

    local unique_names, item_groups = collect_chest_contents(chests)

    local name_count = 0
    for _ in pairs(unique_names) do
        name_count = name_count + 1
    end

    if name_count > 1 then
        for _, balancer in ipairs(group.balancers) do
            update_status_light(balancer.unit_number, balancer, false)
            set_balancer_status(balancer, defines.entity_status_diode.red,
                "Group " .. group_id .. " | Mixed items")
        end
        return true
    end

    local item_label = "Empty"
    for _, group_data in pairs(item_groups) do
        balance_item_group(chests, group_data)
        item_label = "[item=" .. group_data.name .. "] " .. group_data.total
    end

    for _, balancer in ipairs(group.balancers) do
        update_status_light(balancer.unit_number, balancer, true)
        set_balancer_status(balancer, defines.entity_status_diode.green,
            "Group " .. group_id .. " | " .. item_label)
    end
    return true
end

local function on_tick()
    if not storage.groups then
        init_storage()
        rebuild_all_groups()
    end
    local needs_rebuild = false

    for group_id, group in pairs(storage.groups) do
        local ok = process_group(group_id, group)
        if not ok then
            needs_rebuild = true
        end
    end

    if needs_rebuild then
        for unit_number, entity in pairs(storage.balancers) do
            if not entity.valid then
                storage.balancers[unit_number] = nil
                local render = storage.render_objects[unit_number]
                if render and render.valid then
                    render.destroy()
                end
                storage.render_objects[unit_number] = nil
            end
        end
        rebuild_all_groups()
    end
end

local function on_balancer_built(event)
    local entity = event.entity
    if not entity or not entity.valid then return end
    if entity.name ~= "chest-balancer" then return end

    init_storage()
    storage.balancers[entity.unit_number] = entity
    rebuild_all_groups()
end

local function on_balancer_removed(event)
    local entity = event.entity
    if not entity or not entity.valid then return end
    if entity.name ~= "chest-balancer" then return end

    local unit_number = entity.unit_number
    storage.balancers[unit_number] = nil

    local render = storage.render_objects[unit_number]
    if render and render.valid then
        render.destroy()
    end
    storage.render_objects[unit_number] = nil

    rebuild_all_groups()
end

local function is_adjacent_to_balancer(entity)
    local adjacent = get_adjacent_by_name(entity, "chest-balancer")
    return #adjacent > 0
end

local function on_chest_built(event)
    local entity = event.entity
    if not entity or not entity.valid then return end
    if not CHEST_TYPES[entity.type] then return end

    init_storage()
    if is_adjacent_to_balancer(entity) then
        rebuild_all_groups()
    end
end

local function on_chest_removed(event)
    local entity = event.entity
    if not entity or not entity.valid then return end
    if not CHEST_TYPES[entity.type] then return end

    if is_adjacent_to_balancer(entity) then
        rebuild_all_groups()
    end
end

local function rebuild_storage()
    init_storage()
    storage.balancers = {}
    for _, render in pairs(storage.render_objects) do
        if render and render.valid then render.destroy() end
    end
    storage.render_objects = {}

    for _, surface in pairs(game.surfaces) do
        local entities = surface.find_entities_filtered{name = "chest-balancer"}
        for _, entity in pairs(entities) do
            storage.balancers[entity.unit_number] = entity
        end
    end

    rebuild_all_groups()
end

local function on_entity_built(event)
    local entity = event.entity
    if not entity or not entity.valid then return end

    if entity.name == "chest-balancer" then
        on_balancer_built(event)
    elseif CHEST_TYPES[entity.type] then
        on_chest_built(event)
    end
end

local function on_entity_removed(event)
    local entity = event.entity
    if not entity or not entity.valid then return end

    if entity.name == "chest-balancer" then
        on_balancer_removed(event)
    elseif CHEST_TYPES[entity.type] then
        on_chest_removed(event)
    end
end

local entity_filter = {
    {filter = "name", name = "chest-balancer"},
    {filter = "type", type = "container"},
    {filter = "type", type = "logistic-container"},
    {filter = "type", type = "infinity-container"},
}

script.on_init(function()
    init_storage()
end)

script.on_configuration_changed(function()
    rebuild_storage()
end)

script.on_nth_tick(UPDATE_INTERVAL, on_tick)

script.on_event(defines.events.on_built_entity, on_entity_built, entity_filter)
script.on_event(defines.events.on_robot_built_entity, on_entity_built, entity_filter)
script.on_event(defines.events.script_raised_built, on_entity_built, entity_filter)
script.on_event(defines.events.script_raised_revive, on_entity_built, entity_filter)

script.on_event(defines.events.on_player_mined_entity, on_entity_removed, entity_filter)
script.on_event(defines.events.on_robot_mined_entity, on_entity_removed, entity_filter)
script.on_event(defines.events.on_entity_died, on_entity_removed, entity_filter)
script.on_event(defines.events.script_raised_destroy, on_entity_removed, entity_filter)
