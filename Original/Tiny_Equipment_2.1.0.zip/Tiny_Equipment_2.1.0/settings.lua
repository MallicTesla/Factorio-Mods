data:extend({
    {
    type = "bool-setting",
    name = "tinyenergyshield",
    setting_type = "startup",
    default_value = true
    },
    {
    type = "bool-setting",
    name = "tinysolarpanel",
    setting_type = "startup",
    default_value = true
    },  
    {
    type = "bool-setting",
    name = "tinyreactor",
    setting_type = "startup",
    default_value = true
    },
    {
    type = "bool-setting",
    name = "tinybattery",
    setting_type = "startup",
    default_value = true
    },
    {
    type = "bool-setting",
    name = "tinyroboport",
    setting_type = "startup",
    default_value = true
    },
    {
    type = "bool-setting",
    name = "tinynightvision",
    setting_type = "startup",
    default_value = true
    },
    {
    type = "bool-setting",
    name = "tinyexoskeleton",
    setting_type = "startup",
    default_value = true
    },
    {
    type = "bool-setting",
    name = "tinyactivedefense",
    setting_type = "startup",
    default_value = true
    }
})
