data.raw["electric-pole"]["small-electric-pole"].supply_area_distance = 3.5

data.raw["electric-pole"]["medium-electric-pole"].supply_area_distance = 4.5
