
if mods["Krastorio"] then
  require("compatibility.Krastorio")
end





