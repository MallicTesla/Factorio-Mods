-------------------------------------------------- replce ingredients --------------------------------------------------
local item_replace_table = {
  ["loader"] = "loader-kr",
  ["fast-loader"] = "loader-kr-02",
  ["express-loader"] = "loader-kr-03"
  }

-- for recipe_name, recipe in pairs (data.raw.recipe) do

local replacing_by = {
  ["lf-furnace-01"] = data.raw.recipe["lf-furnace-01"],
  ["lf-furnace-02"] = data.raw.recipe["lf-furnace-02"],
  ["lf-furnace-03"] = data.raw.recipe["lf-furnace-03"],
  }


for recipe_name, recipe in pairs (data.raw.recipe) do
  local handlers = recipe.normal and {recipe.normal, recipe.expensive} or {recipe}
  for i, handler in pairs (handlers) do
    for j, ing in pairs (handler.ingredients) do
      local name = ing.name or ing[1]
      local amount =ing.amount or ing[2]
      local type = ing.type or "item"
      local new_name = item_replace_table[name]
      if new_name then
        handler.ingredients[j] = {name = new_name, amount = amount, type = type}
        log ('replaced ingredient ["'..name..'"] with ingredient ["'..new_name..'"] by recipe ["'..recipe_name..'"]')
      end
    end
  end
end








-------------------------------------------------- fix double ingredients --------------------------------------------------

function is_value_in_list (value, list)
  for i, v in pairs (list) do
    if value == v then return true end
  end
  return false
end

function list_of_double_ingredients (ingredients)
  local double_ingredients_list = {}
  local checked_list = {}
  for i, ing in pairs (ingredients) do
    local name = ing.name or ing[1]
    if not is_value_in_list (name, checked_list) then
      table.insert (checked_list, name)
    else
      log ('doubled item: ["'..name..'"]')
      table.insert (double_ingredients_list, name)
    end
  end
  if #double_ingredients_list > 0 then
    return double_ingredients_list
  else
    return nil
  end
end

function merge_double_ingredients (recipe_name, ingredients, double_ingredients_list)
  for i, item_name in pairs (double_ingredients_list) do
    local amount = 0
    local typ = nil
    for j, ing in pairs (ingredients) do
      local name = ing.name or ing[1]
      local new_amount = ing.amount or ing[2]
      if name == item_name then
        amount = amount + new_amount
        ingredients[j] = nil
      end
    end
    table.insert (ingredients, {item_name, amount})
    log ('fixed item: ["' ..item_name..'"] amount: '.. amount .. ' by recipe ["'..recipe_name..'"]')
  end
end

for recipe_name, recipe in pairs (data.raw.recipe) do
  local handlers = recipe.normal and {recipe.normal, recipe.expensive} or {recipe}
  -- log ('recipe: ["'..recipe_name..'"] '..#handlers)
  for i, handler in pairs (handlers) do
    -- log ('handler #'..i)
    local double_ingredients_list = list_of_double_ingredients (handler.ingredients)
    if double_ingredients_list then
      log ('doubles by recipe ["'..recipe_name ..'"]: ' .. #double_ingredients_list)
      merge_double_ingredients (recipe_name, handler.ingredients, double_ingredients_list)
    end
  end
end