require("prototypes.category")

--vanilla
require("prototypes.furnaces-vanilla")


--log ('animation = ' .. serpent.block (data.raw.furnace["electric-furnace"].animation))
--log ('working_visualisations = ' .. serpent.block (data.raw.furnace["electric-furnace"].working_visualisations))

-- added in 6.0.1 from Factorio 1.0.0

table.insert (data.raw.technology.logistics.effects, {type = "unlock-recipe", recipe = "loader"})
--table.insert (data.raw.technology.logistics.effects, {type = "unlock-recipe", recipe = "loader-1x1"})

table.insert (data.raw.technology["logistics-2"].effects, {type = "unlock-recipe", recipe = "fast-loader"})
table.insert (data.raw.technology["logistics-3"].effects, {type = "unlock-recipe", recipe = "express-loader"})
if mods["space-age"] then
table.insert (data.raw.technology["turbo-transport-belt"].effects, {type = "unlock-recipe", recipe = "turbo-loader"})
end
