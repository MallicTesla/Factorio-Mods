--[[ not need from 0.0.1

data:extend({
  {
    type = "item-group",
    name = "loader-furnace",
    order = "c-a",
    inventory_order = "c-a",
    icon = "__Loader-Furnace__/graphics/technology/loader-furnace-gray.png",
    icon_size = 128
  }
})


data:extend({
  {
    type = "item-subgroup",
    name = "lf-furnace",
    group = "loader-furnace",
    order = "a-a"
  },
  {
    type = "item-subgroup",
    name = "lf-chemical-furnace",
    group = "loader-furnace",
    order = "b-a"
  },
  {
    type = "item-subgroup",
    name = "lf-mixing-furnace",
    group = "loader-furnace",
    order = "c-a"
  },
  {
    type = "item-subgroup",
    name = "lf-smelting",
    group = "loader-furnace",
    order = "a-b"
  },
  {
    type = "item-subgroup",
    name = "lf-chemical-smelting",
    group = "loader-furnace",
    order = "b-b"
  },
  {
    type = "item-subgroup",
    name = "lf-mixing-smelting",
    group = "loader-furnace",
    order = "c-b"
  }
})

]]


data:extend({
  {
    type = "recipe-category",
    name = "lf-smelting"
  },
  {
    type = "recipe-category",
    name = "lf-chemical-smelting"
  },
  {
    type = "recipe-category",
    name = "lf-mixing-smelting"
  }
})

