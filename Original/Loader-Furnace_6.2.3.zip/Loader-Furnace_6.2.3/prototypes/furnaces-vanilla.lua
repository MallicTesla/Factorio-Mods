require("lib.colors")
require("lib.entities")

local dsb = false
if mods['DoubleSpeedBelts'] then
  dsb = true
end 

local yellow = RGB{178, 173, 50}
local red = RGB{200, 80, 60}
local cyan = RGB{60, 180, 181}
local green = RGB{133, 193, 130}
local technology_icon = "__Loader-Furnace__/graphics/technology/loader-furnace-gray.png"
local technology_icon_size = 128
local entities = 
{
  add_furnace_entity{
    name = 'lf-furnace-01',
    tint = yellow,
    module_slots= 2,
    crafting_category = {"smelting", "lf-smelting"},
    --crafting_speed =  1*140/3, -- 0.16
    crafting_speed =  1*144/3, -- 0.17
    energy_usage =    1*9000, -- 1*180*48
  },
  
  add_furnace_entity{
    name = 'lf-furnace-02',
    tint = red,
    module_slots= 2,
    crafting_category = {"smelting", "lf-smelting"},
    crafting_speed =  2*144/3,
    energy_usage =    2*9000
  },
  
  add_furnace_entity{
    name = 'lf-furnace-03',
    tint = cyan,
    module_slots= 2,
    crafting_category = {"smelting", "lf-smelting"},
    crafting_speed = dsb and 4*144/3 or 3*144/3,
    energy_usage = 4*9000
  }
}
data:extend(entities)

require("lib.items")
local items = 
{
  add_furnace_item
    {
      name = 'lf-furnace-01',
      -- subgroup = "lf-furnace",
      subgroup = "smelting-machine",
      order = "c[electric-furnace]-a[lf-furnace-01]",
      tint = yellow
    },
  add_furnace_item
    {
      name = 'lf-furnace-02',
      -- subgroup = "lf-furnace",
      subgroup = "smelting-machine",
      order = "c[electric-furnace]-b[lf-furnace-02]",
      tint = red
    },
  add_furnace_item
    {
      name = 'lf-furnace-03',
      -- subgroup = "lf-furnace",
      subgroup = "smelting-machine",
      order = "c[electric-furnace]-c[lf-furnace-03]",
      tint = cyan
    }
}
data:extend(items)

require("lib.recipes")

-- Loader Furnace
local recipes = 
  {
    add_furnace_recipe{
      name = "lf-furnace-01",
      ingredients = 
        {
          {type = "item", name = "loader", amount = 2},
          {type = "item", name = "steel-plate", amount = 50},
          {type = "item", name = "electric-furnace", amount = 48},
          {type = "item", name = "electronic-circuit", amount = 20},
          {type = "item", name = "iron-gear-wheel", amount = 20},
          {type = "item", name = "iron-stick", amount = 20}
        },
      order = "a[loader-furnace]-a[lf-furnace-01]",
      -- subgroup = "lf-furnace",
      -- category = nil,
    },
    add_furnace_recipe{
      name = "lf-furnace-02",
      ingredients = 
        {
          {type = "item", name = "fast-loader", amount = 2},
          {type = "item", name = "steel-plate", amount = 50},
          {type = "item", name = "lf-furnace-01", amount = 3},
          {type = "item", name = "advanced-circuit", amount = 5},
          {type = "item", name = "iron-gear-wheel", amount = 20},
          {type = "item", name = "iron-stick", amount = 20}
        },
      order = "a[loader-furnace]-b[lf-furnace-02]",
      -- subgroup = "lf-furnace",
      -- category = nil,
    },
    add_furnace_recipe{
      name = "lf-furnace-03",
      ingredients = 
        {
          {type = "item", name = "express-loader", amount = 2},
          {type = "item", name = "steel-plate", amount = 50},
          {type = "item", name = "lf-furnace-02", amount = 3},
          {type = "item", name = "advanced-circuit", amount = 50},
          {type = "item", name = "iron-gear-wheel", amount = 20},
          {type = "item", name = "iron-stick", amount = 20},
          {type = "fluid", name = "lubricant", amount = 120}
        },
      order = "a[loader-furnace]-c[lf-furnace-03]",
      -- subgroup = "lf-furnace",
      category = "crafting-with-fluid",
    }
  }

data:extend(recipes)


-- Technologies
require("lib.technologies")
local technologies = 
{
  add_furnace_tech
    {
      name = "lf-furnace",
      icon_size = technology_icon_size,
      icon = technology_icon,
      tier = "01",
      prerequisites = 
        {
          "advanced-material-processing-2",
          -- 'logistic-science-pack',
          'chemical-science-pack',
          
        },
      unit =     
        {
          count = 500, 
          time = 30,      
          ingredients = 
            {
              -- {"science-pack-1", 1},
              -- {"science-pack-2", 1},
              
              {'automation-science-pack', 1},
              {'logistic-science-pack', 1},
              {'chemical-science-pack', 1} -- I don't know why chemical, but it's blue and I need blue one
            } 
        },
      order = "l[loader-furnace]-a[furnace]-a[01]",

      tint = yellow

    },
    add_furnace_tech
    {
      name = "lf-furnace",
      icon_size = technology_icon_size,
      icon = technology_icon,
      tier = "02",
      prerequisites = 
        {
          "lf-furnace-01",
          'production-science-pack'
        },
      unit =     
        {       
          count = 1000,
          time = 60,
          ingredients = 
            {
              -- {"science-pack-1", 1},
              -- {"science-pack-2", 1},
              -- {"science-pack-3", 1}
              
              {'automation-science-pack', 1},
              {'logistic-science-pack', 1},
              {'chemical-science-pack', 1}, -- I don't know why chemical, but it's blue and I need blue one
              {'production-science-pack', 1}
            }
        },
      order = "l[loader-furnace]-a[furnace]-b[02]",
      tint = red

    },
    add_furnace_tech
    {
      name = "lf-furnace",
      icon_size = technology_icon_size,
      icon = technology_icon,
      tier = "03",
      prerequisites = 
        {
          "lf-furnace-02",
          'utility-science-pack'
        },
      unit =     
        {
          count = 2000,
          time = 90,
          ingredients = 
            {
              -- {"science-pack-1", 1},
              -- {"science-pack-2", 1},
              -- {"science-pack-3", 1},
              -- {'production-science-pack', 1}
              
              {'automation-science-pack', 1},
              {'logistic-science-pack', 1},
              {'chemical-science-pack', 1}, -- I don't know why chemical, but it's blue and I need blue one
              {'production-science-pack', 1},
              {'utility-science-pack', 1}
            }
        },
      order = "l[loader-furnace]-a[furnace]-c[03]",
      tint = cyan
    }
}
data:extend(technologies)
if mods["space-age"] then
local entities =
{
  add_furnace_entity{
    name = 'lf-furnace-04',
    icon = "__Loader-Furnace__/graphics/icons/lf-icon-gray.png",
    tint = green,
    module_slots= 2,
    crafting_category = {"smelting", "lf-smelting"},
    crafting_speed = dsb and 8*144/3 or 4*144/3,
    energy_usage = 8*9000
  }
}
data:extend(entities)

local items =
{
  add_furnace_item
    {
      name = 'lf-furnace-04',
      -- subgroup = "lf-furnace",
      subgroup = "smelting-machine",
      order = "d[electric-furnace]-d[lf-furnace-04]",
      tint = green
    }
}
data:extend(items)

local recipes =
  {
    add_furnace_recipe{
      name = "lf-furnace-04",
      ingredients =
        {
          {type = "item", name = "turbo-loader", amount = 2},
          {type = "item", name = "steel-plate", amount = 50},
          {type = "item", name = "lf-furnace-03", amount = 3},
          {type = "item", name = "advanced-circuit", amount = 50},
          {type = "item", name = "iron-gear-wheel", amount = 20},
          {type = "item", name = "iron-stick", amount = 20},
          {type = "fluid", name = "lubricant", amount = 120}
        },
      order = "a[loader-furnace]-c[lf-furnace-03]",
      -- subgroup = "lf-furnace",
      category = "crafting-with-fluid",
    }
  }
data:extend(recipes)

local technologies =
{
    add_furnace_tech
    {
      name = "lf-furnace",
      icon_size = technology_icon_size,
      icon = technology_icon,
      tier = "04",
      prerequisites =
        {
          "lf-furnace-03",
          'utility-science-pack',
          "metallurgic-science-pack"
        },
      unit =
        {
          count = 4000,
          time = 90,
          ingredients =
            {
              -- {"science-pack-1", 1},
              -- {"science-pack-2", 1},
              -- {"science-pack-3", 1},
              -- {'production-science-pack', 1}

              -- {'automation-science-pack', 1},
              -- {'logistic-science-pack', 1},
              -- {'chemical-science-pack', 1}, -- I don't know why chemical, but it's blue and I need blue one
              -- {'production-science-pack', 1},
              -- {'utility-science-pack', 1}

              {"automation-science-pack", 1},
              {"logistic-science-pack", 1},
              {"chemical-science-pack", 1},
              {"production-science-pack", 1},
              {'utility-science-pack', 1},
              {"metallurgic-science-pack", 1}
            }
        },
      order = "l[loader-furnace]-a[furnace]-e[04]",
      tint = green
    }
}
data:extend(technologies)
end
