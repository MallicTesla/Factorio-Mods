function add_furnace_recipe(data)
  local name = data.name
  -- local order = data.order
  -- local subgroup = data.subgroup or nil
  local category = data.category or nil
  local ingredients = data.ingredients
  
  return {
    type = "recipe",
    name = name,
    ingredients = ingredients,
    enabled = false,

    category = category, -- category = "crafting-with-fluid" for express-compatibel furnace
    energy_required = 5,
--    result = name
-- for 2.0:
    results = {
			{type = "item", name = name, amount = 1},
		}
  }
end
