local fluid_boxes = data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes

function add_furnace_entity(data)
	local name = data.name
	local crafting_category = data.crafting_category
	local crafting_speed = data.crafting_speed
	local energy_usage = data.energy_usage
	local icon = data.icon
	local tint = data.tint

	local filename = "__Loader-Furnace__/graphics/entity/lf-furnace-gray.png"


	return {
		type = "furnace",
		name = name,
		icons = {
			{
			icon = "__base__/graphics/icons/electric-furnace.png",
			tint = tint
			}
		},
		icon_size = 32,
		flags = {"placeable-player", "player-creation"},
		minable = {mining_time = 5, result = name},
		max_health = 500,
		corpse = "big-remnants",
		dying_explosion = "medium-explosion",
		light = {intensity = 1, size = 10},
		resistances = {
			{type = "fire", percent = 80},
			{type = "acid", percent = 80}
		},
		collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
		selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
		module_specification = {module_slots = 3, module_info_icon_shift = {0, 0.8}},
		allowed_effects = {"consumption", "speed", "productivity", "pollution", "quality"},
		crafting_categories = crafting_category,
		fast_replaceable_group = "furnace",
		ingredient_count = 4,
		crafting_speed = crafting_speed,
		energy_usage = energy_usage .. "kW",
		result_inventory_size = 1,
		source_inventory_size = 1,

--		fluid_boxes = {
--			{
--				production_type = "input",
--				pipe_picture = assembler3pipepictures(),
--				pipe_covers = pipecoverspictures(),
--				base_area = 10,
--				base_level = -1,
--				pipe_connections = {{type = "input", position = {0, -2}}}
--			},
----      off_when_no_fluid_recipe = true,
--			fluid_boxes_off_when_no_fluid_recipe = true, -- 2.0
--		},		

-- 2.0:
		--fluid_boxes = fluid_boxes,
-- /2.0:		
		
		
		energy_source = {type = "electric", usage_priority = "secondary-input", emmisions = 0.005},
		vehicle_impact_sound = {filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65},
		working_sound = {
			sound = {filename = "__base__/sound/electric-furnace.ogg", volume = 0.7},
			apparent_volume = 1.5
		},
		graphics_set =
    {
		animation = {
			layers = {
				{
					filename = "__Loader-Furnace__/graphics/entity/lf-furnace-gray.png",
						tint = tint,
						frame_count = 1,
						height = 219,
						priority = "high",
						scale = 0.5,
						shift = {
							0.0234375,
							0.1796875
						},
						width = 239
					},
				{
						draw_as_shadow = true,
						filename = "__base__/graphics/entity/electric-furnace/electric-furnace-shadow.png",
						frame_count = 1,
						height = 171,
						priority = "high",
						scale = 0.5,
						shift = {
							0.3515625,
							0.2421875
						},
						width = 227
				}
			}
		},

		working_visualisations = {
			{
				animation = {
						animation_speed = 0.5,
						filename = "__base__/graphics/entity/electric-furnace/electric-furnace-heater.png",
						frame_count = 12,
						height = 56,
						priority = "high",
						scale = 0.5,
						shift = {
							0.0546875,
							1.0234375
						},
						width = 60
				},
				light = {
					color = {
						b = 1,
						g = 1,
						r = 1
					},
					intensity = 0.4,
					shift = {
						0,
						1
					},
					size = 6
				}
			},
			{
				animation = {
						animation_speed = 0.5,
						filename = "__base__/graphics/entity/electric-furnace/electric-furnace-propeller-1.png",
						frame_count = 4,
						height = 25,
						priority = "high",
						scale = 0.5,
						shift = {
							-0.640625,
							-0.578125
						},
						width = 37
				}
			},
			{
				animation = {
						animation_speed = 0.5,
						filename = "__base__/graphics/entity/electric-furnace/electric-furnace-propeller-2.png",
						frame_count = 4,
						height = 15,
						priority = "high",
						scale = 0.5,
						shift = {
							0.109375,
							-1.1875
						},
						width = 23
				}
			}
		},

	}
	}
end

