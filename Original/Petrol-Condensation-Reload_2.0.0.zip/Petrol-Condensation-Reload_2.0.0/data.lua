require("prototypes.recipes")
require("prototypes.technologies")

--require("prototypes.vanilla-modules")

--if mods["SchallModules"] then
--	require("prototypes.schall-modules")
--end