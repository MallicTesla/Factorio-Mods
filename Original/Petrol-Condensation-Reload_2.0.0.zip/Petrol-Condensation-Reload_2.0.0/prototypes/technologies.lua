data:extend
({
  {
    type = "technology",
    name = "oil-condensation",
	icon = "__Petrol-Condensation-Reload__/graphics/light-oil-condensation.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "condense-petroleum-gas"
      },
	  {
        type = "unlock-recipe",
        recipe = "condense-light-oil"
      }
    },
    prerequisites = {"advanced-oil-processing"},
    unit =
    {
		count = 100,
		ingredients = util.table.deepcopy(data.raw.technology["advanced-oil-processing"].unit.ingredients),
		time = 30
    },
    order = "i-j"
  }
})