data:extend({
	{
		type = "recipe",
		name = "condense-petroleum-gas",
		category = "chemistry",
		energy_required = 3,
		enabled = false,
		ingredients =
		{
		  {type="item", name="coal", amount=1},
		  {type="fluid", name="petroleum-gas", amount=80}
		},
		results=
		{
		  {type="fluid", name="light-oil", amount=60}
		},
		main_product = "", --needed to make descriptions from locale show up
		icon = "__Petrol-Condensation-Reload__/graphics/petroleum-gas-condensation.png",
		icon_size = 128,
		subgroup = "fluid-recipes",
		order = "b[fluid-chemistry]-c[condense-petroleum-gas]"
	},
	{
		type = "recipe",
		name = "condense-light-oil",
		category = "chemistry",
		energy_required = 3,
		enabled = false,
		ingredients =
		{
		  {type="item", name="coal", amount=1},
		  {type="fluid", name="light-oil", amount=120}
		},
		results=
		{
		  {type="fluid", name="heavy-oil", amount=100}
		},
		main_product = "", --needed to make descriptions from locale show up
		icon = "__Petrol-Condensation-Reload__/graphics/light-oil-condensation.png",
		icon_size = 128,
		subgroup = "fluid-recipes",
		order = "b[fluid-chemistry]-c[condense-light-oil]"
	},
})