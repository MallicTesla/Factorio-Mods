-- makes condensation recipes get unlocked when you research Advanced Oil Processing

--table.insert
--	(
--		data.raw["technology"]["advanced-oil-processing"].effects,
--		{type = "unlock-recipe", recipe = "condense-petroleum-gas"}
--	)
--	table.insert
--	(
--		data.raw["technology"]["advanced-oil-processing"].effects,
--		{type = "unlock-recipe", recipe = "condense-light-oil"}
--	)
if settings.startup["pcr-coal"].value == false then

data.raw["recipe"]["condense-petroleum-gas"].ingredients =
		{
		  {type="fluid", name="petroleum-gas", amount=80}
		}
data.raw["recipe"]["condense-light-oil"].ingredients =
		{
		  {type="fluid", name="light-oil", amount=120}
		}

end

if mods["angelspetrochem"] then
--move recipes to angel's category
data.raw["recipe"]["condense-petroleum-gas"]["category"] = "chemistry"
data.raw["recipe"]["condense-petroleum-gas"]["subgroup"] = "petrochem-fuel"
data.raw["recipe"]["condense-light-oil"]["category"] = "chemistry"
data.raw["recipe"]["condense-light-oil"]["subgroup"] = "petrochem-fuel"
end
