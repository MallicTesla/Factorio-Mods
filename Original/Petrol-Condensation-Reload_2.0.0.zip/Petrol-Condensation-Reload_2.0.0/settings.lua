data:extend(
{
  {
    type = "bool-setting",
    name = "pcr-coal",
	order = "aba",
    setting_type = "startup",
    default_value = true,
  }
}
)